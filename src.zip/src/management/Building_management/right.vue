<template>
  <div class="">
    <div class="toolright font-white  margin-top20">

      <section class="bulid-iteminfo">
        <section>
          <div class="personinfo">
            <p>
              <span class="size-20 font-blue">实验教学楼</span>
              <span class="float-right">
                            <span class="bgbox-max bg-blue font-gray-111">评分2.6</span>
                        </span>
            </p>
            <p class="col-sm-5 text-left padding0">
                        <span class="size-12 font-gray-666">
                            <i class="fa fa-th-large"></i> 良庆区中心小学</span>
            </p>
            <P class="col-sm-7 text-right padding0">
                        <span class="text-right font-gray-666 size-12">
                        录入时间<span>2018.07.09 08:00:00</span>
                        </span>
            </P>

          </div>
        </section>
        <section>
          <div class="input-group datatime btn-group date-picker input-daterange datatime margin-top10" data-date="today" data-date-format="yyyy-mm-dd"
               data-original-title="" title="">
                    <span class="input-group-btn" data-original-title="" title="">
                        <i class="fa fa-th-large"></i> 时间 </span>
            <input type="text" class="form-control" name="from" id="troubleStartTime">
            <span class="input-group-btn" data-original-title="" title=""> 至 </span>
            <input type="text" class="form-control" name="to" id="troubleEndTime">
            <span class="input-group-btn" data-original-title="" title="">
                        确定
                    </span>
            <span class="input-group-btn" data-original-title="" title=""> 今 周 月 年 </span>
          </div>
        </section>
        <section>
          <div class="row toolcount margin-top40">
            <div class="col-sm-4  font-gray-999 padding-right0">
              <ul class="toolcount-left margin-bottom0 padding-left0" id="toolcount">
                <li>
                  <p class="font-blue size-50 line-height118">
                    112
                  </p>
                </li>
                <li>
                  <p class="size-10">Running State</p>
                </li>
                <li>
                  <p class="size-16 font-blue">总房间数量</p>
                </li>
              </ul>
            </div>
            <div class="col-sm-8 font-gray-999 padding-left0 padding-right0">
              <ul class="toolcount-right padding-left15 margin-bottom0 margin-left15">
                <li>
                  <p class="size-18 font-white">信息统计</p>
                </li>
                <li>
                  <p class="size-10 set-scaleright">Pepair Statistics</p>
                </li>
                <li>
                  <p class="set-width-50 size-12">楼层数量 <span class="font-gray-ccc">14 </span> 预案 <span class="font-gray-ccc">6 </span> </p>
                  <p>使用 <span class="font-gray-ccc">10</span>年<span class="font-gray-ccc">12</span>月</p>
                </li>
                <li class="row text-center">
                  <div class="col-sm-4 container-padding0 personnel-borderright">
                    <p class="size-16 font-white">42</p>
                    <p class="size-12 margin-bottom0">设备总数</p>
                  </div>
                  <div class="col-sm-4 container-padding0 personnel-borderright">
                    <p class="size-16 font-white">25</p>
                    <p class="size-12 margin-bottom0">警报总数</p>
                  </div>
                  <div class="col-sm-4 container-padding0">
                    <p class="size-16 font-white">25</p>
                    <p class="size-12 margin-bottom0">隐患总数</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>
        <section>
          <div class="textandimg">
            <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top10">
              <span class="tool-rect bg-blue"></span>建筑信息
            </h2>
            <div class="row textandimg-main">
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑用途 </span>
                <span class="size-12 font-gray-999">公共 </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑类型 </span>
                <span class="size-12 font-gray-999">超高层</span>
              </div>

              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑年份 </span>
                <span class="size-12 font-gray-999">2014年 </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">结构类型 </span>
                <span class="size-12 font-gray-999">钢混</span>
              </div>

              <div class="col-sm-6">
                <span class="size-12 font-gray-666">楼层数量 </span>
                <span class="size-12 font-gray-999">14层</span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">房间数量 </span>
                <span class="size-12 font-gray-999">112个</span>
              </div>

              <div class="col-sm-6">
                <span class="size-12 font-gray-666">占地面积 </span>
                <span class="size-12 font-gray-999">2354 m² </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑高度 </span>
                <span class="size-12 font-gray-999">545m</span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑经度 </span>
                <span class="size-12 font-gray-999">12.54951 </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑维度 </span>
                <span class="size-12 font-gray-999">26.6659</span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">管理单位 </span>
                <span class="size-12 font-gray-999">中心小学 </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">负责人 </span>
                <span class="size-12 font-gray-999">赵堆船</span>
              </div>

              <div class="col-sm-6">
                <span class="size-12 font-gray-666">平面图 </span>
                <span class="size-12 font-gray-999">按钮 </span>
              </div>
              <div class="col-sm-6">
                <span class="size-12 font-gray-666">建筑标码 </span>
                <span class="size-12 font-gray-999">按钮</span>
              </div>

            </div>
          </div>
        </section>
        <section>
          <div class="row toolcount margin-top10">
            <h2 class="size-16 font-gray-ccc margin-bottom0 margin-top10">
              <span class="tool-rect bg-blue"></span>历史趋势
              <span class="float-right xunjian-left-main-bottom-padding8 popup-inspectbtn font-gray-666">
                            <i class="fa fa-th-large"></i>
                        </span>
            </h2>
            <div id="myChart1" style="width: 400px;height:180px;margin: 0 auto;"></div>
          </div>
        </section>
      </section>
    </div>
  </div>

</template>

<script>
  export default {
    data() {
      return {};
    },
    methods: {
      chart_one() {
        var option = {
          xAxis: {
            type: "category",
            boundaryGap: false,
            data: ["Mon", "123", "Wed", "Thu", "Fri", "Sat", "Sun"],
            show: true,
            axisLine: {
              lineStyle: {
                color: "#999"
              }
            }
          },

          yAxis: {
            type: "value",
            axisLine: {
              lineStyle: {
                color: "#999"
              }
            },
            splitLine: {
              lineStyle: {
                // 使用深浅的间隔色
                color: ["#333"]
              }
            }
          },
          // 图例
          legend: {
            data: ["高", "低"]
          },

          // 调整实际显示的 margin
          grid: {
            y: 30,
            x2: 10,
            y2: 30,
            x: 40,
            borderWidth: 1
          },
          // 数据
          series: [
            {
              data: [100, 499, 50, 1111, 45, 345, 907],
              name: "低",
              type: "line",
              symbol: "none",
              smooth: true,
              color: {
                colorStops: [
                  {
                    offset: 0,
                    color: "#333"
                  }
                ]
              }
            },
            {
              data: [300, 950, 900, 800, 700, 600, 700],
              name: "高",
              type: "line",
              symbol: "none",
              smooth: true,
              areaStyle: { normal: {} },
              color: {
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(255,255,255,0.3)" // 0% 处的颜色
                  }
                ]
              }
            }
          ],
          tooltip: {
            enterable: true,
            trigger: "axis",
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: "line" // 默认为直线，可选为：'line' | 'shadow'
            }
          }
        };



        let myChart2 = this.$echarts.init(document.getElementById("myChart1"));
        myChart2.setOption(option);
      }
    },
    mounted() {
      this.chart_one();
    }
  };
</script>

<style scoped>
  .line-height118 {
    line-height: 118px !important;
  }
  .padding-right16 {
    padding-right: 16px;
  }
</style>
