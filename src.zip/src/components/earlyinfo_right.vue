<template>
  <div class="toolright font-white margin-top0 padding-top0">       
    <!-- 单位信息 -->
    <section class="unit-info border-solid-333 clearfix bg-black">      
      <ul class="list-unstyled">
        <!-- 介绍 -->
        <li class="position-relative">
          <div class="position-absolute-bottom clearfix">
            <!-- 单位信息 -->
            <article class="unit-brief white-space col-sm-10">
              <h3>南宁市良庆区</h3>
              <small><i class="el-icon-location"></i> 广西省南宁市良庆区银海大道710-2号</small>
            </article>
            <!-- 安全评分 -->
            <article class="unit-score">
              <span class="badge bg-blue position-absolute-right">安全评分</span>
              <!-- 分数 -->
              <h1 class="font-red">2.<sub>6</sub></h1>
              <!-- 上升下降标识 -->
              <small class="font-white"><i class="fas fa-arrow-down" title="下降"></i></small>
            </article>
          </div>
          <!-- 单位图片 -->
          <img src="../assets/images/jpg01.jpg" class="img-responsive center-block" alt="单位图片">
        </li>
        <!-- 统计1 -->
        <li>
          <div class="pull-left">
            <h4>段亚伟 <small>15600237854</small></h4>
            <small>消防负责人</small>            
          </div>
          <div class="pull-right">
            <article>
              <h4>367</h4>
              <small>今日警报</small>
            </article>
            <article>
              <h4>214</h4>
              <small>今日隐患</small>
            </article>
            <article>
              <h4>12</h4>
              <small>巡检完成</small>
            </article>
          </div>
        </li>
        <li>
          <!-- 报警信息 -->
          <ul class="early-list list-unstyled">
            <li class="early-single warning-list">
              <article>
                <h5><i class="icon iconfont icon-early"></i>实验教学1号楼3层1203室<span>发生警报</span></h5>
                <h4>              
                  <a href=""><i class="icon iconfont icon-suo-guan-mian-" title="锁定"></i></a>
                  <a href=""><i class="fas fa-bullseye" title="详情"></i></a>
                  <a href=""><i class="icon iconfont icon-guanbi-mian-" title="关闭"></i></a>
                  <a href=""><span class="badge">1</span></a>
                </h4>
              </article>
              <var>
                <p class="col-sm-8">
                  <i class="icon iconfont icon-shebei-mian-"><span>A365F57A89D</span></i>
                  <i class="icon iconfont icon-miehuoqi-mian-"><span>烟雾感应器</span></i>
                </p>
                <p class="col-sm-4">              
                  <span class="badge">332s</span><span class="badge">12:36:47</span>
                </p>
              </var>
            </li>
          </ul>
        </li>
      </ul>  
    </section>
    <!-- <section class="margin-top20">
        <div class="personinfo">
          <p>
            <span class="bgbox-police bg-red font-black size-20">火情</span>&nbsp;
            <span class="size-20 font-blue">F57D 的报警详情</span>
            <span class="float-right">
                      <span class="bgbox-max bg-red font-black">
                          <i class="icon iconfont icon-tongzhi-xian-"></i> 报警中</span>
                  </span>
          </p>
        </div>
      </section>  -->  
    <section class="call-iteminfo margin-top10">
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom10 margin-top20">
            <span class="tool-rect bg-blue"></span>报警发起
            <span class="float-right">
                      <span class="bgbox-max bg-blue font-black">
                          <i class="icon iconfont icon-jiankong-mian-"></i> 监控</span>
                  </span>
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">警报源 </span>
              <span class="size-12 font-gray-999">A365F57D (烟雾感应器)</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">报警类型 </span>
              <span class="size-12 font-gray-999">设备</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">发生地点 </span>
              <span class="size-12 font-gray-999">良庆区中心小学01号楼301室</span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">响应时间 </span>
              <span class="size-12 font-blue">10小时32分</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">报警描述 </span>
              <span class="size-12 font-gray-999">
                          <span class="bgbox-voice bg-blue font-black">
                              <i class="icon iconfont icon-tongzhi-xian-"></i> 32S</span>
                          <span>有事没事报个警震惊一些愚蠢的人类</span>
                      </span>
            </div>
            <div class="textandimg-img">
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom10 margin-top20">
            <span class="tool-rect bg-blue"></span>报警确认
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟(巡检员)</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">指派给 </span>
              <span class="size-12 font-gray-999">赵堆船(无响应)</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">解除时长 </span>
              <span class="size-12 font-blue">1小时32分</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">反馈信息 </span>
              <span class="size-12 font-gray-999">
                          <span class="bgbox-voice bg-blue font-black">
                              <i class="icon iconfont icon-tongzhi-xian-"></i> 32S</span>
                          <span>设备质量不行,乱报警</span>
                      </span>
            </div>
            <div class="textandimg-img">
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom10 margin-top20">
            <span class="tool-rect bg-blue"></span>报警关闭
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟(管理员)</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">关闭说明 </span>
              <span class="size-12 font-gray-999">设备质量不行,乱报警</span>
            </div>
          </div>
        </div>
      </section>
    </section>
  </div>
</template>