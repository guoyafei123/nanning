<template>
  <div class="toolleft margin-right0">
    <section>
      <div class="row toolcount">
        <div class="col-sm-6  font-gray-999 padding-right0">
          <ul class="toolcount-left margin-bottom0 padding-left37" id="toolcount">
            <li>
              <p>26</p>
            </li>
            <li>
              <p class="size-10">Device Total</p>
            </li>
            <li>
              <p class="size-18 font-blue">当前建筑总数</p>
            </li>
          </ul>
        </div>
        <div class="col-sm-6 font-gray-999 padding-left0 padding-right0">
          <ul class="toolcount-right padding-left15 margin-bottom0 margin-left15">
            <li>
              <p class="set-width-50 size-12">辖区单位</p>
              <p class="display-inline-block font-italic">452</p>
            </li>
            <li>
              <p class="set-width-50 size-12">重要建筑</p>
              <p class="display-inline-block font-yellow">34</p>
            </li>
            <li>
              <p class="set-width-50 size-12">超高层建筑</p>
              <p class="display-inline-block font-blue">4</p>
            </li>
            <li>
              <p class="set-width-50 size-12">高危结构</p>
              <p class="display-inline-block font-red">567</p>
            </li>
            <li>
              <p class="set-width-50 size-12">微型消防站</p>
              <p class="display-inline-block font-blue">178</p>
            </li>
          </ul>
        </div>
      </div>
    </section>
    <section>
      <div class="toolcompanyrate margin-top50">
        <ul class="row padding0 margin0 size-12 font-gray-999">
          <li class="col-sm-6">
            <div class="row margin0 padding0">
              <div class="toolcompanyrate-char col-sm-6 padding0">
                <p class="font-red">
                  实验教学楼
                </p>
                <p class="size-16">最低评分</p>
              </div>
              <div class="col-sm-6 padding-top7 padding-left5 padding-right5 size-16 text-center">
                <span class="size-22 font-red">2.6</span>
              </div>
            </div>
          </li>
          <li class="col-sm-6">
            <div class="row margin0 padding0">
              <div class="toolcompanyrate-char col-sm-6 padding0">
                <p class="font-yellow">
                  职工楼22号
                </p>
                <p class="size-16">最高评分</p>
              </div>
              <div class="col-sm-6 padding-top7 padding-left5 padding-right5 size-16 text-center">
                <span class="size-22 font-yellow">8.7</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </section>
    <section>
      <div class="toolroute font-gray-ccc margin-left37">
        <span class="toolroute-rect bg-blue"></span>
        <ul class="padding-left5 padding-right5">
          <li>
            <p class="font-gray-666 size-12">中心小学</p>
          </li>
          <li>
            <p class="font-blue size-16">建筑信息
              <span class="float-right toolroute-padding8 popup-routebtn font-gray-666">
                            <i class="fa fa-th-large"></i>
                        </span>
            </p>
          </li>
          <li>
            <div class="input-group bg-none toolroute-padding8">
              <div class="input-group-btn">
                <button type="button" class="btn btn-default dropdown-toggle dropdown-btnstyle bg-black02" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">全部类型
                  <span class="caret"></span>
                </button>
                <ul class="dropdown-menu toolroute-pan font-gray-666">
                  <li>
                    <a href="#">1</a>
                  </li>
                  <li>
                    <a href="#">2</a>
                  </li>
                  <li>
                    <a href="#">3</a>
                  </li>
                  <li>
                    <a href="#">4</a>
                  </li>

                </ul>
              </div>
              <!-- /btn-group -->
              <input type="text" class="form-control bg-none toolroute-sec " aria-label="hellow">
              <span class="input-group-btn">
                            <button class="btn btn-default dropdown-btnstyle bg-black02 glyphicon-searchdiv" type="button">
                                <span class="glyphicon glyphicon-search"></span>
                            </button>
                        </span>

            </div>
            <!-- /input-group -->
          </li>
          <li>
            <div class="table-responsive">
              <table class="table size-12 table-condensed toolroute-table margin-top10">
                <thead>
                <tr>
                  <th>序号</th>
                  <th>建筑名称</th>
                  <th>所属单位</th>
                  <th>房间数量</th>
                  <th>位置</th>
                  <th>操作</th>
                </tr>
                </thead>
                <tbody id="">
                <tr>
                  <td>1</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td >
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td >
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>9</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>10</td>
                  <td>A1YF789456</td>
                  <td>灭火设备</td>
                  <td>
                    实验室教学楼1号
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                </tbody>
              </table>
            </div>
          </li>
          <li>
            分页
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<script>
    export default {
    }
</script>

<style scoped>

</style>
