<template>
  <div class="toolright font-white  margin-top-20">
    <section class="call-iteminfo display-none">
      <section>
        <div class="personinfo">
          <p>
            <span class="bgbox-police bg-red font-black size-20">火情</span>&nbsp;
            <span class="size-24 font-blue">F57D 的报警详情</span>
            <span class="float-right">
                      <span class="bgbox-max bg-red font-black">
                          <i class="fa fa-th-large"></i> 报警中</span>
                  </span>
          </p>
          <p class="margin-bottom">
                  <span class="size-12 font-gray-666">
                      <i class="fa fa-th-large"></i> 良庆区中心小学</span>
          </p>
        </div>
      </section>
      <section>
              <div class="input-group datatime btn-group date-picker input-daterange datatime margin-top20" data-date="today" data-date-format="yyyy-mm-dd"
                  data-original-title="" title="">
                <span class="input-group-btn" data-original-title="" title="">
                    <i class="fa fa-th-large"></i> 时间 </span>
                <input type="text" class="form-control" name="from" id="troubleStartTime">
                <span class="input-group-btn" data-original-title="" title=""> 至 </span>
                <input type="text" class="form-control" name="to" id="troubleEndTime">
                <span class="input-group-btn" data-original-title="" title="">
                    确定
                </span>
                <span class="input-group-btn" data-original-title="" title=""> 今 周 月 年 </span>
              </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top40">
            <span class="tool-rect bg-blue"></span>报警发起
            <span class="float-right">
                      <span class="bgbox-max bg-blue font-black">
                          <i class="fa fa-th-large"></i> 监控</span>
                  </span>
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">警报源 </span>
              <span class="size-12 font-gray-999">A365F57D (烟雾感应器)</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">报警类型 </span>
              <span class="size-12 font-gray-999">设备</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">发生地点 </span>
              <span class="size-12 font-gray-999">良庆区中心小学01号楼301室</span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">响应时间 </span>
              <span class="size-12 font-blue">10小时32分</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">报警描述 </span>
              <span class="size-12 font-gray-999">
                          <span class="bgbox-voice bg-blue font-black">
                              <i class="fa fa-th-large"></i> 32S</span>
                          <span>有事没事报个警震惊一些愚蠢的人类</span>
                      </span>
            </div>
            <div class="textandimg-img">
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top40">
            <span class="tool-rect bg-blue"></span>报警确认
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟(巡检员)</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">指派给 </span>
              <span class="size-12 font-gray-999">赵堆船(无响应)</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">解除时长 </span>
              <span class="size-12 font-blue">1小时32分</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">反馈信息 </span>
              <span class="size-12 font-gray-999">
                          <span class="bgbox-voice bg-blue font-black">
                              <i class="fa fa-th-large"></i> 32S</span>
                          <span>设备质量不行,乱报警</span>
                      </span>
            </div>
            <div class="textandimg-img">
              <div class="col-sm-3">
                <img src="../assets/images/people.png">
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top40">
            <span class="tool-rect bg-blue"></span>报警关闭
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">确认人 </span>
              <span class="size-12 font-gray-999">段亚伟(管理员)</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">关闭说明 </span>
              <span class="size-12 font-gray-999">设备质量不行,乱报警</span>
            </div>
          </div>
        </div>
      </section>
    </section>
    <section class="call-lineinfo">
        <section>
          <div class="personinfo">
            <p>
              <span class="size-20 font-blue">南宁市良庆区</span>
            </p>
            <p>
              <span class="size-12 font-gray-666"><i class="fa fa-th-large"></i> 良庆区中心小学</span>
            </p>
          </div>
        </section>
        <section>
            <div class="input-group datatime btn-group date-picker input-daterange datatime margin-top20" data-date="today" data-date-format="yyyy-mm-dd"
                data-original-title="" title="">
              <span class="input-group-btn" data-original-title="" title="">
                  <i class="fa fa-th-large"></i> 时间 </span>
              <input type="text" class="form-control" name="from" id="troubleStartTime">
              <span class="input-group-btn" data-original-title="" title=""> 至 </span>
              <input type="text" class="form-control" name="to" id="troubleEndTime">
              <span class="input-group-btn" data-original-title="" title="">
                  确定
              </span>
              <span class="input-group-btn" data-original-title="" title=""> 今 周 月 年 </span>
            </div>
        </section>
        <section>
          <div class="row toolcount">
            <h2 class="size-16 font-gray-ccc margin-top0 margin-bottom0">
              <span class="tool-rect bg-blue"></span>报警数量
            </h2>
            <div class="col-sm-7  font-gray-999 padding-right0">
                
              <div class="row text-center margin-top50">
                <p class="text-left toolcountp1">总数 <span class="font-blue">89 </span></p>
                <div class="col-sm-4 container-padding0 personnel-borderright">
                  <p class="size-16 font-red">42</p>
                  <p class="size-12 margin-bottom0">火情总数</p>
                </div>
                <div class="col-sm-4 container-padding0 personnel-borderright">
                  <p class="size-16 font-blue">13</p>
                  <p class="size-12 margin-bottom0">报警总数</p>
                </div>
                <div class="col-sm-4 container-padding0">
                  <p class="size-16 font-gray-999">25</p>
                  <p class="size-12 margin-bottom0">故障总数</p>
                </div>
              </div>
            </div>
            <div class="col-sm-5 font-gray-999 padding-left0 padding-right0">
              <div id="pieb1" style="width: 100%;height:150px;margin: 0 auto;"></div>
            </div>
          </div>
        </section>
        <section>
          <div class="row toolcount">
            <h2 class="size-16 font-gray-ccc margin-bottom0 margin-top0">
              <span class="tool-rect bg-blue "></span>警报类型
            </h2>
            <div class="font-gray-999 padding-right0 margin-top10 ">
                <div class="row text-left set-padding30">
                  <div class="col-sm-4 container-padding0">
                    <p class="size-12 margin-bottom0">
                      <i class="fa fa-th-large"></i> 报警 263</p>
                  </div>
                  <div class="col-sm-4 container-padding0">
                    <p class="size-12 margin-bottom0">
                      <i class="fa fa-th-large"></i> 火情 23</p>
                  </div>
                  <div class="col-sm-4 container-padding0">
                    <p class="size-12 margin-bottom0">
                      <i class="fa fa-th-large"></i> 故障 123</p>
                  </div>
                </div>
              </div>
            <div id="axis1" style="width: 100%;height:200px;margin: 0 auto;"></div>
          </div>
        </section>
        <section>
          <div class="row toolcount margin-top30">
            <h2 class="size-16 font-gray-ccc margin-bottom0 margin-top0">
              <span class="tool-rect bg-blue"></span>历史趋势
              <span class="float-right xunjian-left-main-bottom-padding8 popup-inspectbtn font-gray-666">
                      <i class="fa fa-th-large"></i>
                  </span>
            </h2>
            <div id="myChart" style="width: 100%;height:180px;margin: 0 auto;"></div>
          </div>
        </section>
      </section>
    <div class="ceshi-btn">
      <button @click="moren">详情</button>
      <button @click="jianzhu">统计</button>
    </div>
  </div>
</template>


<script>
export default {
  data() {
    return {};
  },
  methods: {
    moren() {
      $(".call-iteminfo")
        .addClass("display-block")
        .removeClass("display-none");
      $(".call-lineinfo")
        .addClass("display-none")
        .removeClass("display-block");
    },
    jianzhu() {
      $(".call-lineinfo")
        .addClass("display-block")
        .removeClass("display-none");
      $(".call-iteminfo")
        .addClass("display-none")
        .removeClass("display-block");
    },
    chart_one() {
      var option = {
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: ["Mon", "123", "Wed", "Thu", "Fri", "Sat", "Sun"],
          show: true,
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          }
        },

        yAxis: {
          type: "value",
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          },
          splitLine: {
            lineStyle: {
              // 使用深浅的间隔色
              color: ["#333"]
            }
          }
        },
        // 图例
        legend: {
          data: ["高", "低"]
        },

        // 调整实际显示的 margin
        grid: {
          y: 30,
          x2: 10,
          y2: 30,
          x: 40,
          borderWidth: 1
        },
        // 数据
        series: [
          {
            data: [100, 499, 50, 1111, 45, 345, 907],
            name: "低",
            type: "line",
            symbol: "none",
            smooth: true,
            color: {
              colorStops: [
                {
                  offset: 0,
                  color: "#333"
                }
              ]
            }
          },
          {
            data: [300, 950, 900, 800, 700, 600, 700],
            name: "高",
            type: "line",
            symbol: "none",
            smooth: true,
            areaStyle: { normal: {} },
            color: {
              colorStops: [
                {
                  offset: 0,
                  color: "rgba(255,255,255,0.3)" // 0% 处的颜色
                }
              ]
            }
          }
        ],
        tooltip: {
          enterable: true,
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "line" // 默认为直线，可选为：'line' | 'shadow'
          }
        }
      };
      var pie = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            name: "访问来源",
            type: "pie",
            selectedMode: "single",
            radius: [0, "70%"],
            label: {
              normal: {
                position: "inner"
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            color: ["#bad616", "#333"],
            data: [
              { value: 335, name: "50%", selected: true },
              { value: 679, name: "" }
            ]
          }
        ]
      };

      // 根据值判断柱子颜色的柱状图
      var option1 = {
        color: ["#3398DB"],
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            show: true,
            data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "12"],
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: "value",
            show: false
          }
        ],
        grid: {
          y: 40,
          x2: 0,
          y2: 20,
          x: 0,
          borderWidth: 1
        },
        series: [
          {
            name: "直接访问",
            type: "bar",
            barWidth: "60%",
            data: [10, 52, 200, 334, 390, 330, 220, 192],
            itemStyle: {
              normal: {
                // 值显示在柱子顶部
                label: {
                  show: true,
                  position: "top",
                  textStyle: {
                    color: function(params) {
                      if (params.value > 0 && params.value < 100) {
                        return "#333333";
                      } else if (params.value >= 100 && params.value <= 200) {
                        return "#666666";
                      } else if (params.value >= 200 && params.value <= 300) {
                        return "#999999";
                      }
                      return "#bad616";
                    }
                  },
                  formatter: function(params) {
                    if (params.value == 0) {
                      return "";
                    } else {
                      return params.value;
                    }
                  }
                },
                color: function(params) {
                  if (params.value > 0 && params.value < 100) {
                    return "#333333";
                  } else if (params.value >= 100 && params.value <= 200) {
                    return "#666666";
                  } else if (params.value >= 200 && params.value <= 300) {
                    return "#999999";
                  }
                  return "#bad616";
                }
              }
            }
          }
        ]
      };

      let myChart = this.$echarts.init(document.getElementById("myChart"));
      myChart.setOption(option);
      let axis1b = this.$echarts.init(document.getElementById("axis1"));
      axis1b.setOption(option1);
      let mypie1 = this.$echarts.init(document.getElementById("pieb1"));
      mypie1.setOption(pie);
    }
  },
  mounted() {
    this.chart_one();
  }
};
</script>

<style scoped>
</style>
