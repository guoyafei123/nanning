<template>
  <div class="toolleft margin-right0">
    <section>
      <div class="row toolcount">
        <div class="col-sm-6  font-gray-999 padding-right0">
          <ul class="toolcount-left margin-bottom0 padding-left37" id="toolcount">
            <li>
              <p class="font-red">53</p>
            </li>
            <li>
              <p class="size-10">Warning Number</p>
            </li>
            <li>
              <p class="size-18 font-blue">报警数</p>
            </li>
            <li>
              <p class="set-width-50 size-12">设备占比</p>
              <p class="display-inline-block font-italic">76%</p>
            </li>
            <li>
              <p class="set-width-50 size-12">发生火情</p>
              <p class="display-inline-block font-red font-italic">2</p>
            </li>
            <li>
              <p class="set-width-50 size-12">报警确认</p>
              <p class="display-inline-block ">
                <span class="font-yellow font-italic margin-bottom0">3 </span>/
                <span class="margin-bottom0">30</span>
              </p>
            </li>
          </ul>
        </div>
        <div class="col-sm-6 font-gray-999 padding-left0 padding-right0">
          <ul class="toolcount-right padding-left15 margin-bottom0 margin-left15">
            <li>
              <p class="font-yellow  big-font97">327</p>
            </li>
            <li>
              <p class="size-10  set-scaleright">Hidden Danger Number</p>
            </li>
            <li>
              <p class="size-18 font-blue">故障数</p>
            </li>
            <li>
              <p class="set-width-50 size-12">室内设备</p>
              <p class="display-inline-block font-italic">76</p>
            </li>
            <li>
              <p class="set-width-50 size-12">室外设备</p>
              <p class="display-inline-block  font-italic">13</p>
            </li>
            <li>
              <p class="set-width-50 size-12">主机复位</p>
              <p class="display-inline-block font-italic">48</p>
            </li>
          </ul>
        </div>
      </div>
    </section>
    <section>
      <div class="toolroute font-gray-ccc margin-left37">
        <span class="toolroute-rect bg-blue"></span>
        <ul class="padding-left5 padding-right5">
          <li>
            <p class="font-gray-666 size-12">中心小学</p>
          </li>
          <li>
            <p class="font-blue size-16">警报信息
              <span class="float-right toolroute-padding8 popup-routebtn font-gray-666">
                            <i class="fa fa-th-large"></i>
                        </span>
            </p>
          </li>
          <li>
            <div class="input-group bg-none toolroute-padding8">
              <div class="input-group-btn">
                <button type="button" class="btn btn-default dropdown-toggle dropdown-btnstyle bg-black02" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">全部类型
                  <span class="caret"></span>
                </button>
                <ul class="dropdown-menu toolroute-pan font-gray-666">
                  <li>
                    <a href="#">1</a>
                  </li>
                  <li>
                    <a href="#">2</a>
                  </li>
                  <li>
                    <a href="#">3</a>
                  </li>
                  <li>
                    <a href="#">4</a>
                  </li>

                </ul>
              </div>
              <!-- /btn-group -->
              <input type="text" class="form-control bg-none toolroute-sec " aria-label="hellow">
              <span class="input-group-btn">
                            <button class="btn btn-default dropdown-btnstyle bg-black02 glyphicon-searchdiv" type="button">
                                <span class="glyphicon glyphicon-search"></span>
                            </button>
                        </span>

            </div>
            <!-- /input-group -->
          </li>
          <li>
            <div class="table-responsive">
              <table class="table size-12 table-condensed toolroute-table margin-top10">
                <tr>
                  <th>序号</th>
                  <th>类型</th>
                  <th>报警源</th>
                  <th>发出时间</th>
                  <th>状态</th>
                  <th>操作</th>
                </tr>
                <tr>
                  <td>1</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>9</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
                <tr>
                  <td>10</td>
                  <td>报警</td>
                  <td>段亚伟</td>
                  <td>08:08:08</td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                  <td>
                    <i class="fa fa-th-large font-blue"></i>
                  </td>
                </tr>
              </table>
            </div>
          </li>
          <li>
            分页
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<script>
    export default {
    }
</script>

<style scoped>

</style>
