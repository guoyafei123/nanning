<template>
  <div>
    <section id="information-info" class="toolright margin-top-20">
      <section>
        <div class="personinfo">
          <p>
            <span class="size-24 font-blue">A365 F57D 的设备详情</span>
            <!-- <span class="bgbox-min bg-gray-666 font-black">灭火设备</span> -->
            <span class="float-right">
                    <span class="bgbox-max bg-gray-333 font-gray-999">灭火设备</span>
                </span>
          </p>
          <p>
                <span class="size-12 font-gray-666">
                    <i class="fa fa-th-large"></i> 良庆区中心小学</span>
          </p>
        </div>
      </section>
      <section>
        <div class="row toolcount margin-top20">
          <div class="col-sm-4  font-gray-999 padding-right0">
            <ul class="toolcount-left margin-bottom0 padding-left0" id="toolcount">
              <li>
                <p class="font-blue size-50">
                  正常
                </p>
              </li>
              <li>
                <p class="size-10">Running State</p>
              </li>
              <li>
                <p class="size-16 font-blue">设备运行正常</p>
              </li>
            </ul>
          </div>
          <div class="col-sm-8 font-gray-999 padding-left0 padding-right0">
            <ul class="toolcount-right padding-left15 margin-bottom0 margin-left15">
              <li>
                <p class="size-18 font-white">维保统计</p>
              </li>
              <li>
                <p class="size-10 set-scaleright">Pepair Statistics</p>
              </li>
              <li>
                <p class="set-width-50 size-12">运行时长</p>
                <p class="display-inline-block font-blue">3229分钟
                </p>
              </li>
              <li class="row text-center">
                <div class="col-sm-4 container-padding0 personnel-borderright">
                  <p class="size-16 font-white">42</p>
                  <p class="size-12 margin-bottom0">报警次数</p>
                </div>
                <div class="col-sm-4 container-padding0 personnel-borderright">
                  <p class="size-16 font-white">7</p>
                  <p class="size-12 margin-bottom0">故障次数</p>
                </div>
                <div class="col-sm-4 container-padding0">
                  <p class="size-16 font-white">36</p>
                  <p class="size-12 margin-bottom0">更换周期</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top40">
            <span class="tool-rect bg-blue"></span>设备信息
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">设备名称&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">A365F57D </span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">设备类型&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">灭火设备</span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">投入时间&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">2016.06.07 </span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">设备标码&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">
                            <span class="font-blue">查看 </span>
                            <span class="font-blue"> 下载 </span>
                        </span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">设备位置&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">良庆区中心小学01号楼301室</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">位置坐标&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">116.146132.40.001433</span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">离地高度&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">2.23m</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">距离顶部&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">2.1m</span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">生产厂商&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">广西精密仪器有限公司</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">生产日期&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">2015.03.06</span>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="textandimg">
          <h2 class="size-16 font-gray-ccc margin-bottom20 margin-top40">
            <span class="tool-rect bg-blue"></span>维保信息
          </h2>
          <div class="row textandimg-main">
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">维保单位&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">中心小学 </span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">维保人员&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">赵堆船
                            <i class="fa fa-th-large"></i>
                        </span>
            </div>
            <div class="col-sm-7">
              <span class="size-12 font-gray-666">维保到期&nbsp;&nbsp;</span>
              <span class="size-12 font-yellow">2018.12.06</span>
            </div>
            <div class="col-sm-5">
              <span class="size-12 font-gray-666">更换周期&nbsp;&nbsp;</span>
              <span class="size-12 font-blue">360 天</span>
            </div>
            <div class="col-sm-12">
              <span class="size-12 font-gray-666">维保历史&nbsp;&nbsp;</span>
              <span class="size-12 font-gray-ccc">2条 </span>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="tooltable">
          <div class="table-responsive">
            <table class="table size-12 table-condensed toolroute-table margin-top10">
              <thead>
              <tr>
                <th>维保日期</th>
                <th>维保人</th>
                <th>结果</th>
                <th>备注</th>
              </tr>
              </thead>
              <tr>
                <td>2.17.1.23 12:26:54</td>
                <td>赵堆船</td>
                <td class="font-yellow">维修</td>
                <td class="font-gray-ccc">设备质量不行,乱报警...</td>
              </tr>
              <tr>
                <td>2.17.1.23 12:26:54</td>
                <td>赵堆船</td>
                <td class="font-blue">更换</td>
                <td class="font-gray-ccc">电池没电...</td>
              </tr>
            </table>
          </div>
        </div>
      </section>
    </section>
  </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>

</style>
