import VueResource from 'vue-resource'
Vue.use(VueResource);

import axios from 'axios'
Vue.prototype.$ajax = axios

